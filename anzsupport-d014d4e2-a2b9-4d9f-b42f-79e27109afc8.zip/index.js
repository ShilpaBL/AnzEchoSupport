'use strict';
var Alexa = require("alexa-sdk");
var appId = ''; //'amzn1.echo-sdk-ams.app.your-skill-id';

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);
    alexa.appId = appId;
    alexa.registerHandlers(newSessionHandlers, guessModeHandlers, startGameHandlers);
    alexa.execute();
};

var states = {
    GUESSMODE: '_GUESSMODE', // User is trying to guess the number.
    STARTMODE: '_STARTMODE'  // Prompt the user to start or restart the game.
};

var newSessionHandlers = {
    'NewSession': function() {
        if(Object.keys(this.attributes).length === 0) {
            this.attributes['endedSessionCount'] = 0;
            this.attributes['gamesPlayed'] = 0;
            this.attributes['last'] = 0;
            this.attributes['current'] = 0;
        } 
        this.handler.state = states.STARTMODE;
        this.emit(':ask', ' <audio src="https://s3.amazonaws.com/sreeks/wJvBznCE-339455-levelclearer-grass29.mp3" /> Welcome to A N Z support. Would you like to start?',
            'Say yes to start.');
    },
    "AMAZON.StopIntent": function() {
      this.emit(':tell', "Goodbye! thanks for using A N Z support.");  
    },
    "AMAZON.CancelIntent": function() {
      this.emit(':tell', "Goodbye!");  
    },
    'SessionEndedRequest': function () {
        console.log('session ended!');
        //this.attributes['endedSessionCount'] += 1;
        this.emit(":tell", "Goodbye!");
    }
};

var startGameHandlers = Alexa.CreateStateHandler(states.STARTMODE, {
    'NewSession': function () {
        this.emit('NewSession'); // Uses the handler in newSessionHandlers
    },
    'AMAZON.HelpIntent': function() {
        var message = 'Say yes if you want to proceed.';
        this.emit(':ask', message, message);
    }
    ,
    'GetPin': function() {
        this.attributes["current"] = 0;
        var pin = this.event.request.intent.slots.pinsec.value;
        if(pin == 1234){
             this.handler.state = states.GUESSMODE;
             this.emit(':ask', 'Welcome Sree Krishna!. <audio src="https://s3.amazonaws.com/sreeks/yEq8JhQp-334916-akrythael-bard-melody.mp3" />  How can I help you today?. ');
        }
        else{
            this.emit(':ask', 'Your pin number , <say-as interpret-as="digits">' + pin + '</say-as> is incorrect. Please try again.');
        }
    },
    'AMAZON.YesIntent': function() {
        this.emit(':ask', 'Good, Can you confirm your security code?.','Can you tell your security code?.');
       // this.emit(':ask', 'Starting! ' + 'First number is ','1');
    },
    'AMAZON.NoIntent': function() {
        console.log("NOINTENT");
        this.emit(':tell', 'Ok, see you next time!');
    },
    "AMAZON.StopIntent": function() {
      console.log("STOPINTENT");
      this.emit(':tell', "Goodbye!");  
    },
    "AMAZON.CancelIntent": function() {
      console.log("CANCELINTENT");
      this.emit(':tell', "Goodbye!");  
    },
    'SessionEndedRequest': function () {
        console.log("SESSIONENDEDREQUEST");
        //this.attributes['endedSessionCount'] += 1;
        this.emit(':tell', "Goodbye! The session is ending.");
    },
    'Unhandled': function() {
        console.log("UNHANDLED");
        var message = 'Say yes to continue, or no to exit.';
        this.emit(':ask', message, message);
    }
});


var guessModeHandlers = Alexa.CreateStateHandler(states.GUESSMODE, {
    'NewSession': function () {
        this.handler.state = '';
        this.emitWithState('NewSession'); // Equivalent to the Start Mode NewSession handler
    },
    'GetCounterPartyMap': function() {
         var mapName = this.event.request.intent.slots.partyname.value;
         
         this.emit(':ask', 'Mapping request has been sent to Level 2 support for further processing.','');
    },
    'GetTradeDetail': function() {
        var tradeId = this.event.request.intent.slots.tradeid.value;
        var status = '';
        const newWorldTrades = ['3000','2000','1000','8888','5555','1212','4000','5000','7000'];
        const murexTrades = ['6666','2000','5555','1000'];


         if(tradeId !== null)
         {
             if(newWorldTrades.indexOf(tradeId) === -1)
             {
                 status = 'This trade is not avaiable in New World dashboard. Have mailed the Level 2 support to restart the MARKITWIRE connector';
             }
             else if(newWorldTrades.indexOf(tradeId) >-1)
             {
                if(murexTrades.indexOf(tradeId) ===-1)
                {
                    status = 'This trade is avaiable in New World dashboard but missing in Murex database. CounterParty mapping is missing. Do you want to map and resend.' ;
                }
                else
                {
                    status = 'This trade is avaiable in New World dashboard and Murex database but stuck in workflow. Have mailed the Level 2 support to restart the workflow';
                }
             }
             else {
                    status = 'Could not locate this trade, Please provide a valid Trade.';
             }
         }

        //this.emit(':ask', 'Trade ' + tradeId + ' has been processed succesfully.','');
        this.emit(':ask', status,'');
    },
    'GetRates':function(){
        var currency1 = this.event.request.intent.slots.currency.value;
        var currencybase1 = this.event.request.intent.slots.currencybase.value;
        var currency = currency1.toString().split(" ").join("").toUpperCase();
        var currencybase = currencybase1.toString().split(" ").join("").toUpperCase();
               var https = require('https');
               var url = "https://currencydatafeed.com/api/data.php?token=0c7xblkbvebzz8o06rs7&currency=" + currency + "/" + currencybase;
       
            var that = this;
        https.get(url, function(res) {
                    console.log("Got response: " + res.statusCode);
                    var str='';
                      res.on('data', function (data) {
                            str += data;
          
                      });
                    
                      res.on('end', function () {
          var r =  JSON.parse(str);
                    that.emit(':ask','<prosody rate="slow">The rate of currency pair ' + currency + ' and ' +currencybase + ' is ' +  r.currency[0].value +  ' as on ' +  r.currency[0].date  + '</prosody>','Anything else I can do for you?');
          
                      });
                  
                  }).on('error', function(e) {
                    console.log("Got error: " + e.message);
                     that.emit(':ask','Error while retrieving rates. Please try again later.','Anything else I can do for you?');
             
                  });
              
           
     },
    
    'GetTradeSummary': function() {
        var tradefamily = this.event.request.intent.slots.tradefamily.value;
        var status='Find the summary for ' + tradefamily + ".";
        
        if(tradefamily !== null && tradefamily === 'I R D')
        {
            status = 'There are 694 Interest Rate Derivatives trades booked  today. 12 got cancelled. 6 got restructured and 5 got cancel and reissued as on today.';
        }
        else if(tradefamily === 'bond')
        {
            status = 'There are 936 bond trades booked today. 6 got cancelled. 3 got restructured and 8 got cancel and reissued as on today.';
        }
        else
        {
            status = 'There are 453 trades booked today. 3 got cancelled. 4 got restructured and 2 got cancel and reissued as on today.';
        }
        this.emit(':ask',status,'');
        
    },
    'GetChannelHealthSummary': function() {
        var channelname = this.event.request.intent.slots.channelname.value;
        var status='';
        
        if(channelname !== null)
        {
          for (var i = 0, len = activeChannels.length; i < len; i++) {
                if(channelname.toUpperCase() == activeChannels[i].toUpperCase())
                {
                    status = 'up and running' ;
                } 
            }
            for (var j = 0, l = passiveChannels.length; j < l; j++) {
                if(channelname.toUpperCase() == passiveChannels[j].toUpperCase())
                {
                   status = 'down' ;
               } 
            }
        }
        this.emit(':ask', channelname + ' is '+ status ,'');
    },
    'GetChannelSummary': function() {
        var channelname = this.event.request.intent.slots.channelname.value;
        
        this.emit(':ask', 'Channel name is ' + channelname,'');
        
    },
     'GetChannelOwnerName': function() {
        var channelname = this.event.request.intent.slots.nwchannelname.value;
        var channelDetails = channelList.Channels[channelname.toUpperCase()];
        var ownerName = channelDetails.owner;
    
        this.emit(':ask', '<prosody rate="slow">Owner of the channel ' + channelname + ' is ' + ownerName + '</prosody>','');
        
    },
    'UpcomingChanges': function() {
        var channelname = this.event.request.intent.slots.channelname.value;
      
        this.emit(':ask', 'Three Channels CSS,TOMS,SPIDER are getting upgraded this weekend with minor bug fixes.','');
        
    },
     'GetHolidayList': function() {
        this.emit(':ask', holidayLst ,'');
        
    },
    'AMAZON.YesIntent': function() {
        this.emit(':ask', 'Can you please give the counter party name for missing mapping for citi 0023 by saying, Map Counter party and then counter party name.','Please provde the missing mapping.');
    },
    'AMAZON.NoIntent': function() {
        console.log("NOINTENT");
        this.emit(':tell', 'Is there anything else i can help you.');
    },
    'AMAZON.HelpIntent': function() {
        this.emit(':ask', 'No help available.');
    },
    "AMAZON.StopIntent": function() {
        console.log("STOPINTENT");
      this.emit(':tell', "Goodbye! Thanks for using A N Z support.");  
    },
    "AMAZON.CancelIntent": function() {
        console.log("CANCELINTENT");
    },
    'SessionEndedRequest': function () {
        console.log("SESSIONENDEDREQUEST");
        this.attributes['endedSessionCount'] += 1;
        this.emit(':tell', "Goodbye!  Thanks for using A N Z support.");
    },
    'Unhandled': function() {
        console.log("UNHANDLED");
        this.emit(':ask', 'Sorry, I didn\'t get that.', 'Sorry, I didn\'t get that.');
    }
});

                
                                                
                                                
var activeChannels = ['CITIALLOC','CITITRADE','CLS-GRID','CSS','TOMS','SKY','TRADE BOOK'];
var passiveChannels = ['DSMATCH','EMSX','Ffastfill','FinIQ','SPIDER','SENTRY'];

var channelList ={"Channels":{
                                                "TRADE BOOK": {
                                                                   "name":"TRADE BOOK",
                                                                   "volumes":"400",
                                                                   "onBoarded":"2015/05",
                                                                   "owner":"Kumarasamy Loganathan"
                                                },
                                                "PRIME TRADE": {
                                                                    "name":"SPIDER",
                                                                   "volumes":"50",
                                                                   "onBoarded":"2012/01",
                                                                   "owner":"Perumal Adarsh"
                                                },
                                                "SENTRY": {
                                                                   "name":"SENTRY",
                                                                     "volumes":"500",
                                                                   "onBoarded":"2014/04",
                                                                   "owner":"Kumarasamy Loganathan"
                                                },
                                                "SKY": {
                                                                     "name":"SKY",
                                                                     "volumes":"50",
                                                                   "onBoarded":"2015/03",
                                                                   "owner":"Gangopadhyay Chiranjit"
                                                },
                                                "TOMS": {
                                                                   "name":"TOMS",
                                                                    "volumes":"1500",
                                                                   "onBoarded":"",
                                                                   "owner":"Mina Abraham"
                                                }
}};

var holidayLst = ['New Years Day 01 January 2018','Australia Day  26 January 2018','Labour Day 12 March 2018','Easter Saturday 31 March 2018',
'Easter Sunday 01 April 2018','Easter Monday 02 April 2018','Anzac Day 25 April 2018','Queens Birthday 11 June 2018','AFL Grand Final Eve, 01 October 2018',
'Christmas Day 25 December 2018','Boxing Day 26 December 2018'];


                            
